package com.eahost.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.util.UUID;

/** The "Android" object the EA HOST page talks to. */
public class Bridge {
    private final Activity act;
    private final SharedPreferences prefs;

    Bridge(Activity a) {
        act = a;
        prefs = a.getSharedPreferences("eahost", 0);
    }

    @JavascriptInterface
    public String deviceId() {
        String id = Settings.Secure.getString(act.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (id == null || id.length() < 8) {
            id = prefs.getString("dev", null);
            if (id == null) {
                id = UUID.randomUUID().toString();
                prefs.edit().putString("dev", id).apply();
            }
        }
        return "and-" + id;
    }

    @JavascriptInterface
    public boolean hasOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(act);
    }

    @JavascriptInterface
    public void requestOverlay() {
        act.runOnUiThread(() -> {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.getPackageName()));
                act.startActivity(i);
            } catch (Exception e) { }
        });
    }

    @JavascriptInterface
    public void showBubble(String img, String name, String server, String device, String cfg) {
        prefs.edit().putString("server", server == null ? "" : server).putString("device", device == null ? "" : device)
                .putString("cfg", cfg == null ? "" : cfg).putString("name", name == null ? "EA HOST" : name)
                .putBoolean("stop", false).apply();
        try (FileOutputStream f = new FileOutputStream(new File(act.getFilesDir(), "bubble.img"))) {
            f.write((img == null ? "" : img).getBytes("UTF-8"));
        } catch (Exception e) { }
        Intent i = new Intent(act, BubbleService.class);
        if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i); else act.startService(i);
    }

    @JavascriptInterface
    public void hideBubble() {
        act.stopService(new Intent(act, BubbleService.class));
    }

    @JavascriptInterface
    public void setConfig(String cfg) {
        prefs.edit().putString("cfg", cfg == null ? "" : cfg).apply();
    }

    /** true once if the user stopped the bot from the floating bubble */
    @JavascriptInterface
    public boolean consumeStop() {
        boolean s = prefs.getBoolean("stop", false);
        if (s) prefs.edit().putBoolean("stop", false).apply();
        return s;
    }
}
