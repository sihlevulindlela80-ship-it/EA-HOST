package com.eahost.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Vibrator;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Floating robot bubble shown over other apps (e.g. MetaTrader) while the bot is running.
 * Tap = open EA HOST.  Press and hold = stop the bot.
 */
public class BubbleService extends Service {
    private WindowManager wm;
    private ImageView view;
    private WindowManager.LayoutParams lp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private int size;

    @Override
    public IBinder onBind(Intent i) { return null; }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        prefs = getSharedPreferences("eahost", 0);
        startForegroundNow();
        if (view == null) createBubble();
        return START_NOT_STICKY;
    }

    private void startForegroundNow() {
        String name = prefs.getString("name", "EA HOST");
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("bot", "Trading bot", NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, "bot");
        } else {
            nb = new Notification.Builder(this);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = nb.setContentTitle(name + " is running").setContentText("Tap to open EA HOST")
                .setSmallIcon(R.drawable.ic_stat).setContentIntent(pi).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private void createBubble() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        size = dp(64);
        view = new ImageView(this);
        view.setImageBitmap(ring(null));
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(12);
        lp.y = dp(180);
        try { wm.addView(view, lp); } catch (Exception e) { stopSelf(); return; }
        view.setOnTouchListener(new Touch());
        loadPicture();
    }

    private class Touch implements View.OnTouchListener {
        float dx, dy; int sx, sy; boolean moved, held;
        final Runnable hold = () -> { held = true; stopBot(); };

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dx = e.getRawX(); dy = e.getRawY(); sx = lp.x; sy = lp.y; moved = false; held = false;
                    ui.postDelayed(hold, 700);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                    if (Math.abs(mx) > dp(6) || Math.abs(my) > dp(6)) { moved = true; ui.removeCallbacks(hold); }
                    if (moved) { lp.x = sx + (int) mx; lp.y = sy + (int) my; try { wm.updateViewLayout(view, lp); } catch (Exception x) { } }
                    return true;
                case MotionEvent.ACTION_UP:
                    ui.removeCallbacks(hold);
                    if (!moved && !held) openApp();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    ui.removeCallbacks(hold);
                    return true;
            }
            return false;
        }
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try { startActivity(i); } catch (Exception e) { }
    }

    /** long press: tell the server to stop, remember it, and let the app know */
    private void stopBot() {
        try { ((Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).vibrate(60); } catch (Exception e) { }
        prefs.edit().putBoolean("stop", true).apply();
        final String server = prefs.getString("server", ""), device = prefs.getString("device", "");
        if (!server.isEmpty()) new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(server.replaceAll("/+$", "") + "/bot").openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(6000); c.setReadTimeout(6000); c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                OutputStream o = c.getOutputStream();
                o.write(("{\"device\":\"" + device.replace("\"", "") + "\",\"run\":false}").getBytes("UTF-8"));
                o.close(); c.getResponseCode(); c.disconnect();
            } catch (Exception e) { }
        }).start();
        openApp();
        stopSelf();
    }

    /** read the picture the page handed over (data: URL or http link) off the main thread */
    private void loadPicture() {
        new Thread(() -> {
            Bitmap bmp = null;
            try {
                String d = readFile(new File(getFilesDir(), "bubble.img"));
                if (d.startsWith("data:")) {
                    byte[] b = Base64.decode(d.substring(d.indexOf(',') + 1), Base64.DEFAULT);
                    bmp = BitmapFactory.decodeByteArray(b, 0, b.length);
                } else if (d.startsWith("http")) {
                    InputStream in = new URL(d).openStream();
                    bmp = BitmapFactory.decodeStream(in);
                    in.close();
                }
            } catch (Exception e) { }
            final Bitmap fin = bmp;
            if (fin != null) ui.post(() -> { if (view != null) view.setImageBitmap(ring(fin)); });
        }).start();
    }

    private static String readFile(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384]; int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    /** round picture with a green ring */
    private Bitmap ring(Bitmap src) {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = size / 2f - dp(3);
        p.setColor(0xFF0F1A4D);
        c.drawCircle(size / 2f, size / 2f, r, p);
        if (src != null) {
            int s = Math.min(src.getWidth(), src.getHeight());
            Bitmap sq = Bitmap.createBitmap(src, (src.getWidth() - s) / 2, (src.getHeight() - s) / 2, s, s);
            Bitmap sc = Bitmap.createScaledBitmap(sq, size, size, true);
            p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            c.drawBitmap(sc, 0, 0, p);
            p.setXfermode(null);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(3));
        p.setColor(0xFF27D17A);
        c.drawCircle(size / 2f, size / 2f, size / 2f - dp(1.5f), p);
        return out;
    }

    @Override
    public void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (view != null && wm != null) { try { wm.removeView(view); } catch (Exception e) { } }
        view = null;
        super.onDestroy();
    }
}
