EA HOST - Android app project

BEFORE BUILDING - open  app/src/main/assets/EA_HOST.html  and set (near the top of the script):
    const SERVER_ADDRESS  = "https://your-trading-server";    // connect / start / stop / brokers
    const LICENSE_ADDRESS = "https://your-licence-server";    // license-server.js (one key = one device)
In the portal file set  APP_URL = "eahost://open"  so "Open in app" opens THIS app.

BUILD THE APK - choose one:
 A) Without Android Studio (GitHub):  create a free GitHub repository, upload everything in this folder
    (keep the .github folder), open the Actions tab > "Build APK" > Run workflow. When it is green, open the run
    and download "EA-HOST-apk" > app-debug.apk. Install it on the phone (allow "install unknown apps").
 B) Android Studio: File > Open this folder, wait for sync, Build > Build APK(s). The APK is in app/build/outputs/apk/debug/.

ON THE PHONE
 - First Start asks for "Display over other apps" - allow it so the robot bubble can float over MetaTrader.
 - Bubble: tap = open EA HOST, press and hold = stop the bot.
 - For the Play Store you need a signed release (Build > Generate Signed Bundle) and a 512 icon: playstore-icon-512.png.
